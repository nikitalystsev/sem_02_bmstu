/*
Слайд 4
*/

#ifndef _TEST_02_H_

#define _TEST_02_H_


struct date
{
	int day;
	int month;
	int year;

};


#endif