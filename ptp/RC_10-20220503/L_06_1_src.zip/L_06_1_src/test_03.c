/*
Cлайд 7
*/

#include <stdio.h>

struct s_1
{
    int a;
    int b;
    char c;
};

struct s_2
{
    int a;
    int b;
    double d;
};

int main(void)
{
    struct s_1 a;
    struct s_2 b;
    int s_1;

    (void) a;
    (void) b;
    (void) s_1;

    return 0;
}